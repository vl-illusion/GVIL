# The GVIL Dataset
- images: all the images
- vqa_annotations.json: the questions and ground truth answers (humanlik, not humanlike) in the following format:
```
{
    "01_01.jpg__0": {
        "type": "samediff_qa",
        "q_id": 0,
        "question": "Do the two red balls have the same color?",
        "answer_match": "no",       # the humanlike answer 
        "answer_mismatch": "yes",   # the not humanlike answer
        "img": "01_01.jpg"
    },
    ...
}
```
- vg_annotations.json: the visual grounding queries and ground truth bounding boxes (humanlike, not humanlike) in the following format:
```
{
    "01_01.jpg__0": {
        "type": "localization",
        "q_id": 0,
        "query": "darker red ball",
        "bbox_match": [     # the humanlike answer 
            26,
            28,
            1416,
            1418
        ],
        "bbox_mismatch": [  # the not humanlike answer 
            1604,
            28,
            3009,
            1423
        ],
        "img": "01_01.jpg"
    },
    ...
}
```
- pair_info.json: information about how the images are paired for evaluation
- raw_annotations: the raw annotations for each image before generating templated questions and grounding queries 

